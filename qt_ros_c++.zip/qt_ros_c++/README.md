Project todo::

1. Create a boost shared pointer class which has a method to create a gauss
2. Make GUI so that we can input param to create a gauss from the shared pointer class
3. Include ROS functions
4. Use polymophism, function overloading, casting and all important features of c++ 
5. Add doxygen
6. Pointer and reference 
