#!/usr/bin/env python

import rospy
from std_msgs.msg import String
import re
import subprocess

def parse_awusbmanager_output(output):
    devices = []
    other_info = {}
    current_group = None
    parsing_devices = True

    # Split the output into lines and process each line
    lines = output.splitlines()
    for i, line in enumerate(lines):
        line = line.strip()

        if parsing_devices:
            # Check for group line
            group_match = re.match(r'\*\s+Group\s+\d+\s+\(([^)]+)\)', line)
            if group_match:
                current_group = group_match.group(1)
                continue

            # Check for device line
            device_match = re.match(r'\+\s+(.*?)\s+\((AW[0-9\-\.]+)\)\s+\((In-use by you)\)', line)
            if device_match:
                device_name = device_match.group(1).strip()
                device_id = device_match.group(2).strip()
                device_status = device_match.group(3).strip()

                devices.append({
                    'group': current_group,
                    'name': device_name,
                    'id': device_id,
                    'status': device_status
                })
            else:
                # End of device section if the line contains no devices
                if re.search(r'\*\s+means Autoconnect enabled', line):
                    parsing_devices = False

        if not parsing_devices:
            # Parse other information
            if ": " in line:
                key, value = line.split(": ", 1)
                other_info[key.strip()] = value.strip()

    return devices, other_info



def parse_device_info(output):
    devices = []
    lines = output.strip().split("\n")

    for line in lines:
        line = line.strip()
        if line.startswith("Device Name:"):
            device_name = line.split(": ", 1)[1]
        elif line.startswith("Device ID:"):
            device_id = line.split(": ", 1)[1]
        elif line.startswith("Status:"):
            status = line.split(": ", 1)[1]
            devices.append({
                'name': device_name,
                'id': device_id,
                'status': status
            })
    
    return devices



def publish_device_info():
    rospy.init_node('USB_devices_info_publisher', anonymous=True)
    # Run the 'awusbmanager LIST' command and capture its output
    try:
        result = subprocess.run(['awusbmanager', 'LIST'], capture_output=True, text=True, check=True)
        output = result.stdout
        print("Command output captured successfully.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running the command: {e}")
        return

    devices, other_info = parse_awusbmanager_output(output)


    # Create publishers for each device
    publishers = {}
    for device in devices:
        topic_name = f"/USB_device/{device['name'].replace(' ', '_').replace('/', '_')}"
        publishers[topic_name] = rospy.Publisher(topic_name, String, queue_size=10)
        rospy.loginfo(f"Publisher created for topic: {topic_name}")

    rate = rospy.Rate(1)  # 1 Hz
    while not rospy.is_shutdown():
        for device in devices:
            topic_name = f"/USB_device/{device['name'].replace(' ', '_').replace('/', '_')}"
            msg = f"Name: {device['name']}, ID: {device['id']}, Status: {device['status']}"
            publishers[topic_name].publish(msg)
            #rospy.loginfo(f"Published to {topic_name}: {msg}")
        rate.sleep()

if __name__ == '__main__':
    try:
        publish_device_info()
    except rospy.ROSInterruptException:
        pass

