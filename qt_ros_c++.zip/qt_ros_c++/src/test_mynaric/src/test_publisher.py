#!/usr/bin/env python
import nidaqmx 
import rospy
from std_msgs.msg import String
from nidaqmx.constants import AcquisitionType, TerminalConfiguration
from nidaqmx.constants import (
    ACExcitWireMode, AccelChargeSensitivityUnits, AccelSensitivityUnits,
    AccelUnits, AngleUnits, BridgeConfiguration, BridgeElectricalUnits,
    BridgePhysicalUnits, BridgeUnits, CJCSource, ChargeUnits,
    CurrentShuntResistorLocation, CurrentUnits,
    EddyCurrentProxProbeSensitivityUnits, ExcitationSource,
    ForceIEPESensorSensitivityUnits, ForceUnits, FrequencyUnits,
    LVDTSensitivityUnits, LengthUnits, PressureUnits, RTDType,
    RVDTSensitivityUnits, ResistanceConfiguration, ResistanceUnits,
    SoundPressureUnits, StrainGageBridgeType,
    StrainGageRosetteMeasurementType, StrainGageRosetteType, StrainUnits,
    TEDSUnits, TemperatureUnits, TerminalConfiguration, ThermocoupleType,
    TorqueUnits, VelocityIEPESensorSensitivityUnits, VelocityUnits,
    VoltageUnits)

def main():
    rospy.init_node('test_publisher')
    pub = rospy.Publisher('test_topic', String, queue_size=10)
    rate = rospy.Rate(1)

    while not rospy.is_shutdown():
        msg = String()
        with nidaqmx.Task() as task:
                task.ai_channels.add_ai_rtd_chan("cDAQ1Mod1/ai0", resistance_config=ResistanceConfiguration.FOUR_WIRE,  current_excit_source= ExcitationSource.INTERNAL, current_excit_val=1.0e-3)
                task.timing.cfg_samp_clk_timing(rate=50, sample_mode=AcquisitionType.CONTINUOUS)
                #print(task.read_all())
                #print(task.read(number_of_samples_per_channel=1))
                temp_data = task.read(number_of_samples_per_channel=1)

        msg.data = "Hello, temp. is {}".format(temp_data)
        pub.publish(msg)
        rate.sleep()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
