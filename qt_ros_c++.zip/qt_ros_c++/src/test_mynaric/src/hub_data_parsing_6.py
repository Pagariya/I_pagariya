import re
import subprocess

def parse_awusbmanager_output(output):
    devices = []
    other_info = {}
    current_group = None
    parsing_devices = True

    # Split the output into lines and process each line
    lines = output.splitlines()
    for i, line in enumerate(lines):
        line = line.strip()

        if parsing_devices:
            # Check for group line
            group_match = re.match(r'\*\s+Group\s+\d+\s+\(([^)]+)\)', line)
            if group_match:
                current_group = group_match.group(1)
                continue

            # Check for device line
            device_match = re.match(r'\+\s+(.*?)\s+\((AW[0-9\-\.]+)\)\s+\((In-use by you)\)', line)
            if device_match:
                device_name = device_match.group(1).strip()
                device_id = device_match.group(2).strip()
                device_status = device_match.group(3).strip()

                devices.append({
                    'group': current_group,
                    'name': device_name,
                    'id': device_id,
                    'status': device_status
                })
            else:
                # End of device section if the line contains no devices
                if re.search(r'\*\s+means Autoconnect enabled', line):
                    parsing_devices = False

        if not parsing_devices:
            # Parse other information
            if ": " in line:
                key, value = line.split(": ", 1)
                other_info[key.strip()] = value.strip()

    return devices, other_info

def main():
    # Run the 'awusbmanager LIST' command and capture its output
    try:
        result = subprocess.run(['awusbmanager', 'LIST'], capture_output=True, text=True, check=True)
        output = result.stdout
        print("Command output captured successfully.")
    except subprocess.CalledProcessError as e:
        print(f"An error occurred while running the command: {e}")
        return

    # Print the captured output for debugging
    print("Captured Output:\n" + output)

    devices, other_info = parse_awusbmanager_output(output)

    print("Devices:")
    for device in devices:
        print(f"  Device Name: {device['name']}, Device ID: {device['id']}, Status: {device['status']}")

    print("\nOther Information:")
    for key, value in other_info.items():
        print(f"  {key}: {value}")

if __name__ == "__main__":
    main()

