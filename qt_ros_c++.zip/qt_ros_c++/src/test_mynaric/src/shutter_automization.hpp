#pragma once

#ifndef Q_MOC_RUN

#include <pololu_tic_ros/Setpoint.h> 
#include <std_srvs/SetBool.h>  
#include <std_srvs/Trigger.h> 
#include <QtCore/qobject.h>
#include <deque>
#include <ros/ros.h>
#include <utilities/config_helper.hpp>
#include <fiber_alignement_stage_gui/ui_fiber_alignement_stage_gui.h>

#endif

using namespace std;
using namespace Eigen;

class ShutterAutomization: public QObject{
    Q_OBJECT
    public:
        ShutterAutomization(Utilities::ConfigHelperPtr config = nullptr, Ui::FIBER_ALIGNEMENT_STAGE_GUI *ui = nullptr);
    public Q_SLOTS:
        /**
         * @brief Slot to move shutter connected to move_shutter signal.
        */
        void move_shutter();
        /**
         * @brief Slot to reset shutter position.
        */
        void reset_shutter_motor();
        /**
         * @brief Slot for emergency stop.
        */
        void emergency_shutter_motor_stop();
    Q_SIGNALS:
        /**
         * @brief Signal to move shutter connected to move_shutter() function. 
         * @param move_angle angle to move
        */
        void move_shutter_signal(float move_angle);

    private:

    public: 
        ros::ServiceClient shutter_position_service;
        ros::ServiceClient shutter_emergency_stop_service;
        ros::ServiceClient shutter_reset_position_service;
    private:
        ros::NodeHandlePtr nh; //!< 
        Ui::FIBER_ALIGNEMENT_STAGE_GUI *ui;
        Utilities::ConfigHelperPtr config;
        float move_angle;

};


typedef boost::shared_ptr<ShutterAutomization> ShutterAutomizationPtr;