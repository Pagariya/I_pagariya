#!/usr/bin/env python

import nidaqmx 
import rospy
from std_msgs.msg import String




def callback(msg):
    rospy.loginfo("I heard temp. is: %s", msg.data)
    # with nidaqmx.Task() as task:
	#     task.ai_channels.add_ai_rtd_chan("cDAQ1Mod1/ai0", resistance_config=ResistanceConfiguration.FOUR_WIRE,  current_excit_source= ExcitationSource.INTERNAL, current_excit_val=1.0e-3)
	#     task.timing.cfg_samp_clk_timing(rate=50, sample_mode=AcquisitionType.CONTINUOUS)
	#     #print(task.read_all())
	#     print(task.read(number_of_samples_per_channel=50))
    

def test_subscriber():
    rospy.init_node('test_subscriber', anonymous=True)
    rospy.Subscriber('test_topic', String, callback)
    rospy.spin()

if __name__ == '__main__':
    test_subscriber()

