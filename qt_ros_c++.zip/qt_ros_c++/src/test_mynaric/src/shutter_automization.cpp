#include "hw/shutter_automization.hpp"


ShutterAutomization::ShutterAutomization(Utilities::ConfigHelperPtr config, Ui::FIBER_ALIGNEMENT_STAGE_GUI *ui):
        config(config),ui(ui){
    if (!ros::isInitialized())
    {
        int argc = 0;
        char **argv = NULL;
        ros::init(argc, argv, "shutter automization");
    }
    nh = ros::NodeHandlePtr(new ros::NodeHandle);
    // subscribe to pololu services 
    shutter_position_service = nh->serviceClient<pololu_tic_ros::Setpoint>("set_position");
    shutter_emergency_stop_service = nh->serviceClient<std_srvs::SetBool>("emergency_stop");
    shutter_reset_position_service = nh->serviceClient<std_srvs::Trigger>("reset_position");
}


void ShutterAutomization::move_shutter(){
    pololu_tic_ros::Setpoint msg;
    if (ui->open_shutter->isChecked()){
        msg.request.value = 50;
    }
    if (ui->close_shutter->isChecked()){
        msg.request.value = 100;
    }
    if(shutter_position_service.call(msg)){
        ROS_INFO("Request: %d, Response: %d", msg.request.value, msg.response.success);    
        ROS_ERROR("movement service failed...");    
    }
}


void ShutterAutomization::reset_shutter_motor(){
    std_srvs::Trigger reset_position_srv;
    if(!shutter_reset_position_service.call(reset_position_srv)){
        ROS_ERROR("reset service failed...");    
    }
}



void ShutterAutomization::emergency_shutter_motor_stop(){
    std_srvs::SetBool emergency_stop_srv;
    emergency_stop_srv.request.data = true;  
    if(!shutter_emergency_stop_service.call(emergency_stop_srv)){
        ROS_ERROR("emergency_stop service failed...");  
    }
}




