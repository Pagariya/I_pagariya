#include "rqt_example_cpp/generate_random.hpp"

GenerateRandom::GenerateRandom(Ui::MyPluginWidget *ui):
      ui(ui){
        
}

void GenerateRandom::generate_slot(){
    std::cout << "in generate slot" << std::endl;
    ui->label_2->setText(QString::number(5,'g',2));
}

// void GenerateRandom::generate_signal(){
//     std::cout << "in generate signal" << std::endl;
// }
