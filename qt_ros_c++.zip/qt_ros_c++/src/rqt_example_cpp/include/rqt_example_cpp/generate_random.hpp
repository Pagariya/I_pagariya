#pragma once

#ifndef Q_MOC_RUN

#include <rqt_example_cpp/ui_my_plugin.h>
#include <QtCore/qobject.h>
#include <iostream>
#include <boost/shared_ptr.hpp>  // Include the Boost shared_ptr header

#endif

class GenerateRandom:public QObject {
    Q_OBJECT
    public:
        GenerateRandom(Ui::MyPluginWidget *ui = nullptr);
    public Q_SLOTS:
        void generate_slot();
    Q_SIGNALS:
        void generate_signal();
    public:
        Ui::MyPluginWidget *ui;
};


typedef boost::shared_ptr<GenerateRandom> GenerateRandomPtr;