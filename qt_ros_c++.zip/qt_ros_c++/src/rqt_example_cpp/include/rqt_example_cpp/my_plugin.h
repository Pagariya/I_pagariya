#ifndef rqt_example_cpp_my_plugin_H
#define rqt_example_cpp_my_plugin_H

#include <cstdint>
#include <rqt_gui_cpp/plugin.h>
#include <rqt_example_cpp/ui_my_plugin.h>
#include <QWidget>
#include <rqt_example_cpp/generate_random.hpp>

// kurt added these includes
#include <ros/ros.h>
#include <std_msgs/Int32.h>
#include <QString>

namespace rqt_example_cpp {

class MyPlugin
  : public rqt_gui_cpp::Plugin
{
  Q_OBJECT
public:
  MyPlugin();
  virtual void initPlugin(qt_gui_cpp::PluginContext& context);
  virtual void shutdownPlugin();
  virtual void saveSettings(qt_gui_cpp::Settings& plugin_settings, qt_gui_cpp::Settings& instance_settings) const;
  virtual void restoreSettings(const qt_gui_cpp::Settings& plugin_settings, const qt_gui_cpp::Settings& instance_settings);

  // Comment in to signal that the plugin has a way to configure it
  // bool hasConfiguration() const;
  // void triggerConfiguration();
private:
  Ui::MyPluginWidget ui;
  QWidget* widget_;

  // kurt added all these
  ros::NodeHandle ros_node_handle;
  ros::Subscriber my_subscriber;
  void ros_data_callback(const std_msgs::Int32 message);

// kurt added this section
public Q_SLOTS:
  void setText();

// kurt added this section
Q_SIGNALS:
  void setDataValue();

public:
  long int current_value;
  GenerateRandomPtr generate_random;
};

}  // namespace rqt_example_cpp
#endif  // rqt_example_cpp_my_plugin_H
