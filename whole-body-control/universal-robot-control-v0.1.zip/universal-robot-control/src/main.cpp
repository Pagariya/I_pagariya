#include "urc/robot_model.hpp"
#include "urc/computed_torque.hpp"
#include <iostream>
int main(int argc, char** argv) {
  try {
    const std::string urdf = argc > 1 ? argv[1] : "models/arm6/arm6.urdf";
    urc::RobotModel robot(urdf);
    auto q = robot.neutral();
    auto v = Eigen::VectorXd::Zero(robot.nv());
    auto a = Eigen::VectorXd::Zero(robot.nv());
    urc::ComputedTorqueController controller(robot, Eigen::VectorXd::Constant(robot.nv(),100), Eigen::VectorXd::Constant(robot.nv(),20));
    std::cout << "Robot nq=" << robot.nq() << ", nv=" << robot.nv() << ", na=" << robot.na() << "\n";
    std::cout << "Tool position: " << robot.framePosition(q,"tool0").transpose() << "\n";
    std::cout << "Mass matrix:\n" << robot.massMatrix(q) << "\n";
    std::cout << "Gravity compensation torques: " << controller.update(q,v,q,v,a).transpose() << "\n";
  } catch (const std::exception& e) { std::cerr << "Error: " << e.what() << "\n"; return 1; }
}
