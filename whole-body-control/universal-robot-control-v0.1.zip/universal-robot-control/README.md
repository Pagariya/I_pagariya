# Universal Robot Control — v0.1

**C++20 + Pinocchio + Eigen + GoogleTest** foundation for a reusable robot control framework.

## Start in GitHub Codespaces
1. Upload the repository to GitHub, then select **Code → Codespaces → Create codespace**.
2. Open the terminal. Run `~/.pixi/bin/pixi run test`.
3. Run `~/.pixi/bin/pixi run demo`.

Alternatively, if `pixi` is on your PATH, use `pixi run test` and `pixi run demo`.
The first run downloads dependencies and may take several minutes.

## Contents
- `RobotModel`: URDF loading, optional floating base, FK, frame Jacobians, mass matrix, nonlinear effects, RNEA and ABA.
- `ComputedTorqueController`: fixed-base, fully actuated joint controller.
- `models/arm6/arm6.urdf`: a **synthetic educational six-joint arm**, not a UR5e or hardware-accurate model.
- Seven tests: model dimensions, floating-base representation, inverse/forward dynamics consistency, mass matrix SPD, gravity, computed-torque equilibrium, invalid input.

## Math
For a fixed-base arm, `tau = M(q) [a_des + Kp(q_des-q) + Kd(v_des-v)] + h(q,v)`.
Pinocchio `rnea` computes this inverse dynamics expression directly.
For floating-base robots, the equation must additionally account for underactuation and contacts:
`M(q) a + h(q,v) = S^T tau + J_c^T lambda`.
The current computed-torque controller deliberately rejects floating-base robots.

## Important limitations
- No MuJoCo simulator integration yet (next release).
- No contact-constrained dynamics, humanoid locomotion, QP, MPC, ROS 2 or real-time guarantees yet.
- No actuator torque saturation or safety-rated features. Never connect this code directly to physical hardware.
- This initial release has not been compiled in this authoring environment. Run the included CI/tests in Codespaces and report any dependency/API compatibility issues.
- `RobotModel` owns mutable Pinocchio scratch data and is not thread-safe. Create one instance per control thread or redesign the data ownership.
- Current API allocates dynamically and is for correctness/prototyping, not a 1 kHz real-time deployment.

## Planned next milestones
1. MuJoCo headless adapter and simulation step loop.
2. State/command interface with preallocated memory.
3. Joint trajectory generation and measured tracking metrics.
4. Floating-base contact Jacobians and constrained QP whole-body controller.
5. Humanoid and quadruped models, standing and locomotion.
